package calangles;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class Converse {

	public static CalAngles cal = new CalAngles();

	public static float[] mds_time_axis;
	
	public static PXCPoint3DF32[][] Rot_axis_list ;    
	public static PXCPoint3DF32[][] Pos_real_list ;

	public static void Init(int size){
		
		System.out.println("The size is "+size);
		
		Pos_real_list = new PXCPoint3DF32[size][22];
		for(int i = 0 ;i<size;i++){
			Pos_real_list[i]= new PXCPoint3DF32[22];
			for(int t=0; t<22; t++)
				Pos_real_list[i][t]= new PXCPoint3DF32();
		}
		
		Rot_axis_list = new PXCPoint3DF32[size][22];
		for(int i = 0 ;i<size;i++)
			Rot_axis_list[i]= new PXCPoint3DF32[22];
	}
	
	public static void Single_pos_set(String line_string,int time_axis,int index){
		float gv[] = String2Float(line_string);
		//System.out.println("Set "+time_axis+" "+index+" "+gv[1]);
		//Pos_real_list[time_axis][index] = new PXCPoint3DF32();
		Pos_real_list[time_axis][index].x=gv[1];
		Pos_real_list[time_axis][index].y=gv[2];
		Pos_real_list[time_axis][index].z=gv[3];
		//System.out.println(Pos_real_list[time_axis][index].x+" "+Pos_real_list[time_axis][index].y
		//		+" "+Pos_real_list[time_axis][index].z);
	}
	public static void Real_pos_set(){

		File file = new File("E:/Eclipse JEE/short socket/model/Real_Joints_Pos.txt");
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String tempString = null;
            tempString = reader.readLine();
            //System.out.println("Whole zhenshu is "+tempString);
            mds_time_axis=new float[Integer.parseInt(tempString)];
            Init(mds_time_axis.length);
            
            for(int index=0;index<mds_time_axis.length;index++)
            {
	            tempString = reader.readLine();
	            mds_time_axis[index] = String2Float(tempString)[1];
	        	tempString = reader.readLine();
	        	Single_pos_set(tempString,index,0);
	            for (int cnt_line = 2;cnt_line<=21;cnt_line++)
	            {
	            	tempString = reader.readLine();
	            	Single_pos_set(tempString,index,cnt_line);
	            }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
        }
	}
	
	public static PXCPoint3DF32 Pos_sub(PXCPoint3DF32 child ,PXCPoint3DF32 parent){
		PXCPoint3DF32 resultPos = new PXCPoint3DF32();
		//System.out.println("Pos_sub "+index);
		//System.out.println(child.x+" "+child.y+" "+child.z);
		resultPos.x = child.x-parent.x;
		resultPos.y = child.y-parent.y;
		resultPos.z = child.z-parent.z;
		//System.out.println("Pos_sub result "+resultPos.x+" "+resultPos.y+" "+resultPos.z);
		return resultPos;
	}
	
	public static void RotSet(int time_axis,int jointIndex, int parentIndex, int childIndex,int caoluu){
		Rot_axis_list[time_axis][caoluu] = new PXCPoint3DF32();
		//System.out.println("In RotSet "+time_axis+" "+jointIndex+" "+childIndex);
		Rot_axis_list[time_axis][caoluu] = cal.calAngles(
				Pos_sub(Pos_real_list[time_axis][jointIndex],
						Pos_real_list[time_axis][parentIndex]),
				Pos_sub(Pos_real_list[time_axis][childIndex],
						Pos_real_list[time_axis][jointIndex]));
		
		//if(jointIndex==6)
		//	System.out.println("???"+Rot_axis_list[time_axis][jointIndex].x);
	}
	public static void RootRotSet(int time_axis){
		
		PXCPoint3DF32 init18= new PXCPoint3DF32();
		init18.x=(float) 6.92513;
		init18.y=(float) 15.1452;
		init18.z=(float) 0.120883;
		PXCPoint3DF32 init6= new PXCPoint3DF32();
		init6.x=(float) -3.82466;
		init6.y=(float) 15.7071;
		init6.z=(float) -0.666846;
		PXCPoint3DF32 root= new PXCPoint3DF32();
		root.x=(float) 0.0;
		root.y=(float) 0.0;
		root.z=(float) 0.0;
		PXCPoint3DF32 caolulu2= new PXCPoint3DF32();
		PXCPoint3DF32 caolulu1= new PXCPoint3DF32();
		caolulu1=cal.calAngles(
				Pos_sub(Pos_real_list[time_axis][18],
						Pos_real_list[time_axis][0]),
				Pos_sub(init18,
						root)
				);
		caolulu2=cal.calAngles(
				Pos_sub(Pos_real_list[time_axis][6],
						Pos_real_list[time_axis][0]),
				Pos_sub(init6,
						root)
				);
		Rot_axis_list[time_axis][0]= new PXCPoint3DF32();
		Rot_axis_list[time_axis][0].x=(caolulu1.x+caolulu2.x)/2;
		Rot_axis_list[time_axis][0].y=(caolulu1.y+caolulu2.y)/2;
		Rot_axis_list[time_axis][0].z=(caolulu1.z+caolulu2.z)/2;
	}
	public static void ZeroRotSet(int time_axis, int index){
		Rot_axis_list[time_axis][index]= new PXCPoint3DF32();
		Rot_axis_list[time_axis][index].x=0;
		Rot_axis_list[time_axis][index].y=0;
		Rot_axis_list[time_axis][index].z=0;
	}
	public static void RotRecursive(int time_axis){
		RootRotSet(time_axis);
		RotSet(time_axis,3,0,4,1);
		RotSet(time_axis,4,3,5,6);
		ZeroRotSet(time_axis,7);
		RotSet(time_axis,6,0,7,2);
		RotSet(time_axis,7,6,8,8);
		RotSet(time_axis,8,7,9,9);
		ZeroRotSet(time_axis,10);
		RotSet(time_axis,10,0,11,3);
		RotSet(time_axis,11,10,12,11);
		RotSet(time_axis,12,11,13,12);
		ZeroRotSet(time_axis,13);
		RotSet(time_axis,14,0,15,4);
		RotSet(time_axis,15,14,16,14);
		RotSet(time_axis,16,15,17,15);
		ZeroRotSet(time_axis,16);
		RotSet(time_axis,18,0,19,5);
		RotSet(time_axis,19,18,20,17);
		RotSet(time_axis,20,19,21,18);
		ZeroRotSet(time_axis,19);
		try{
		//FileOutputStream out = null;
			/*
			File fw = new File("E:/add2.txt");
			//FileOutputStream fop = new FileOutputStream(fw);
			FileWriter writer = new FileWriter("E:/add2.txt", true);
			writer.write((new String(time_axis+" "+mds_time_axis[time_axis]+"\n")));
			writer.flush();
			for(int i=0;i<20;i++)
			{
					
				String tmp_str = new String(Rot_axis_list[time_axis][i].x+" "+Rot_axis_list[time_axis][i].y+" "+Rot_axis_list[time_axis][i].z+"\n");
				writer.write(tmp_str);
				writer.flush();
			}*/
		}
		catch (Exception e) {   
	            e.printStackTrace();   
	     }   
	}

	public static float[] String2Float(String goodsVolume){
		float gv[];
		int i = 0; 
		StringTokenizer tokenizer = new StringTokenizer(goodsVolume, " ");
		gv = new float[tokenizer.countTokens()];
		while (tokenizer.hasMoreTokens()) {
		    String d = tokenizer.nextToken();
		    gv[i] = Float.valueOf(d);
		    i++;
		}
		return gv;
	}

	//recursive mds_pos_joint
	public static void Pos_Shit(){
		/*
		mds_pos_joint[0]=Pos_sub(realSense_joint[0],realSense_joint[0]);
		mds_pos_joint[3]=Pos_sub(realSense_joint[3],realSense_joint[0]);
		mds_pos_joint[6]=Pos_sub(realSense_joint[6],realSense_joint[0]);
		mds_pos_joint[10]=Pos_sub(realSense_joint[10],realSense_joint[0]);
		mds_pos_joint[14]=Pos_sub(realSense_joint[14],realSense_joint[0]);*/
	}
	public static void PosRecursive(){
		/*
		for(int i=3;i<21;i++){
			mds_pos_joint[i]= new PXCPoint3DF32();
			mds_pos_joint[i].x=0;
			mds_pos_joint[i].y=0;
			mds_pos_joint[i].z=0;
		}*/
	}
}
