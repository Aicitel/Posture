package calangles;

public class PXCPoint3DF32 {

		public float x;
		public float y;
		public float z;
}
