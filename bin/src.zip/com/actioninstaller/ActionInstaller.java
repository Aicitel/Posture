package com.actioninstaller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import calangles.Converse;

import com.ms3dstructure.SMs3dJointFrames;
import com.ms3dstructure.SMs3dKeyFrame;
import com.ms3dstructure.TimeNSpace;
import com.util.Constants;

public class ActionInstaller {

	//Members  
	private int m_iNumJoints;                  //Number of joints
	private int m_iNumFrames;                  //Number of frames
	private SMs3dJointFrames[] m_JointsFrames; //Joints' frames
	private TimeNSpace[][] m_JointsPos;        //Position of all joints in every frame
	
	//Getter
	public SMs3dJointFrames[] getM_Joints() {
		return m_JointsFrames;
	}
	public TimeNSpace[][] getM_JointsPos() {
		return m_JointsPos;
	}
	public int getM_iNumJoints() {
		return m_iNumJoints;
	}
	
	//Constructor
	public ActionInstaller(int numJoints) throws Exception {
		//Get the number of joints
		if (numJoints < 0)
			throw new Exception("Negative number of joints");
		m_iNumJoints = numJoints;
		
		//New joints
		m_JointsFrames = new SMs3dJointFrames[numJoints];
	}
	
	//Load action info file
	public void LoadActionInfo(String fileName) throws Exception {

		File file = new File(fileName);
		BufferedReader reader = null;
		
		try {
			reader = new BufferedReader(new FileReader(file));
			String line = null;
			
			//Read Number of frames
			if ((line = reader.readLine()) == null)
			    throw new Exception("Wrong action info file.\n");
			int frameNum = Integer.parseInt(line);
			if (frameNum < 0)
				throw new Exception("The numbers of frame of this file is negative\n");
			else
				m_iNumFrames = frameNum;
			
			//New JointsPos
			m_JointsPos = new TimeNSpace[m_iNumJoints][m_iNumFrames];
			
			//Read info 
			float frameTime, x, y, z;
			for (int i = 0;i < m_iNumFrames;i++)
			{
				//Read head of a frame
				if ((line = reader.readLine()) == null)
				    throw new Exception("Wrong action info file.\n");
				String temp[] = line.split(" ");
				if (temp.length != 2)
					throw new Exception("Wrong action info file.\n");
				//frameIndex = Integer.parseInt(temp[0]);
				frameTime = Float.parseFloat(temp[1]);
				//Read body of a frame
				for (int j = 0;j < Constants.JOITNS_NUM_HAND_CAPTURE;j++)
				{
					if ((line = reader.readLine()) == null)
					    throw new Exception("Wrong action info file.\n");
					String temp1[] = line.split(" ");
					if (temp1.length != 4)
						throw new Exception("Wrong action info file.\n");
					x = Float.parseFloat(temp1[1]);
					y = Float.parseFloat(temp1[2]);
					z = Float.parseFloat(temp1[3]);
					if (j < 1) {   
						m_JointsPos[j][i] = new TimeNSpace();
						m_JointsPos[j][i].FillTXYZ(frameTime, x, y, z);
					}
					else if (j > 1) {
						m_JointsPos[j-1][i] = new TimeNSpace();
						m_JointsPos[j-1][i].FillTXYZ(frameTime, x, y, z);
					}		
				}
			}
			
			reader.close();
			
			RS2OpenGL();
			
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null)
				reader.close();
		}
	}

    //Install Joints
	public void InstallAllJoints() {
		//New jointsframes
		for (int i = 0;i < 20;i++)
			m_JointsFrames[i] = new SMs3dJointFrames();
		InstallAllJoint();
	}
	private void InstallAllJoint(){
		Converse.Real_pos_set();
		for(int axis_index=0; axis_index<Converse.mds_time_axis.length;axis_index++){
			//Converse.PosRecursive();
			Converse.RotRecursive(axis_index);
		}
		//InstallRoot();
		for(int index=0; index<20; index++){
			InstallJoint(index);
			//System.out.println(index+" Finish");
		}
	}
	
	private void InstallJoint(int index) {
		int real_index = index;
		m_JointsFrames[index].m_sNumRotFrames = (short) m_iNumFrames;
		m_JointsFrames[index].m_sNumTransFrames = (short) m_iNumFrames;
		m_JointsFrames[index].m_RotKeyFrames = new SMs3dKeyFrame[m_iNumFrames];
		m_JointsFrames[index].m_TransKeyFrames = new SMs3dKeyFrame[m_iNumFrames];
		//Install rotate key frames
		for (int i = 0; i < m_iNumFrames;i++) {
			//System.out.println("Here i is "+i);
			
			m_JointsFrames[index].m_RotKeyFrames[i] = new SMs3dKeyFrame(); 
			m_JointsFrames[index].m_RotKeyFrames[i].FillTXYZ(m_JointsPos[index][i].m_fTime,
				Converse.Rot_axis_list[i][real_index].y, 
				Converse.Rot_axis_list[i][real_index].x,
				Converse.Rot_axis_list[i][real_index].z
				);
		}
		//Install translate key frames
		for (int i = 0;i < m_iNumFrames;i++) {
			m_JointsFrames[index].m_TransKeyFrames[i] = new SMs3dKeyFrame();
			m_JointsFrames[index].m_TransKeyFrames[i].FillTXYZ(m_JointsPos[index][i].m_fTime,
					0,0,0);
		}
	}
	/*
	private void InstallRoot() {
		m_JointsFrames[0].m_sNumRotFrames = (short) m_iNumFrames;
		m_JointsFrames[0].m_sNumTransFrames = (short) m_iNumFrames;
		m_JointsFrames[0].m_RotKeyFrames = new SMs3dKeyFrame[m_iNumFrames];
		m_JointsFrames[0].m_TransKeyFrames = new SMs3dKeyFrame[m_iNumFrames];
		//Install rotate key frames
		for (int i = 0;i < m_iNumFrames;i++) {
			m_JointsFrames[0].m_RotKeyFrames[i] = new SMs3dKeyFrame();
			m_JointsFrames[0].m_RotKeyFrames[i].FillTXYZ(m_JointsPos[0][i].m_fTime,
				0.0f, 0.0f, 0.0f);
		}
		//Install translate key frames
		for (int i = 0;i < m_iNumFrames;i++) {
			m_JointsFrames[0].m_TransKeyFrames[i] = new SMs3dKeyFrame();
			m_JointsFrames[0].m_TransKeyFrames[i].FillTXYZ(m_JointsPos[0][i].m_fTime,
				m_JointsPos[0][i].m_XYZ.m_fParamX, 
				m_JointsPos[0][i].m_XYZ.m_fParamY,
				m_JointsPos[0][i].m_XYZ.m_fParamZ);
		}
	}
	
	private void InstallEmptyAction(int jointIndex) {
		m_JointsFrames[jointIndex].m_sNumRotFrames = 1;
		m_JointsFrames[jointIndex].m_sNumTransFrames = 1;
		m_JointsFrames[jointIndex].m_RotKeyFrames = new SMs3dKeyFrame[1];
		m_JointsFrames[jointIndex].m_TransKeyFrames = new SMs3dKeyFrame[1];
		m_JointsFrames[jointIndex].m_RotKeyFrames[0] = new SMs3dKeyFrame();
		m_JointsFrames[jointIndex].m_RotKeyFrames[0].FillTXYZ(
				m_JointsPos[0][m_iNumFrames-1].m_fTime,
				0.0f, 0.0f, 0.0f);
		m_JointsFrames[jointIndex].m_TransKeyFrames[0] = new SMs3dKeyFrame();
		m_JointsFrames[jointIndex].m_TransKeyFrames[0].FillTXYZ(
				m_JointsPos[0][m_iNumFrames-1].m_fTime,
				0.0f, 0.0f, 0.0f);
	}*/
	
	//Tranverse position from Real Sense to OpenGL
	private void RS2OpenGL() {
		float corrected_value_y = 0.15f;
		float corrected_value_z = 0.25f;
		for (int i = 0;i < m_iNumJoints;i++) {
			for (int j = 0;j < m_iNumFrames;j++) {
				m_JointsPos[i][j].m_XYZ.m_fParamX *= Constants.SCALE;
				m_JointsPos[i][j].m_XYZ.m_fParamY += corrected_value_y;
				m_JointsPos[i][j].m_XYZ.m_fParamY *= Constants.SCALE;
				m_JointsPos[i][j].m_XYZ.m_fParamZ = corrected_value_z - m_JointsPos[i][j].m_XYZ.m_fParamZ;
				m_JointsPos[i][j].m_XYZ.m_fParamZ *= Constants.SCALE;
			}
		}
	}
	
}
