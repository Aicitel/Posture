package com.ms3dstructure;

public class SMs3dJointFrames {

	public short m_sNumRotFrames;
	public short m_sNumTransFrames;
	
	public SMs3dKeyFrame[] m_RotKeyFrames;
	public SMs3dKeyFrame[] m_TransKeyFrames;
	
}
