package com.ms3dstructure;

public class TimeNSpace extends SMs3dKeyFrame {

}
