package com.ms3dstructure;

public class TripleFloat {

	public float m_fParamX;
	public float m_fParamY;
	public float m_fParamZ;
	
	public void setXYZ(float x, float y, float z)
	{
		m_fParamX = x;
		m_fParamY = y;
		m_fParamZ = z;
	}
	
}
