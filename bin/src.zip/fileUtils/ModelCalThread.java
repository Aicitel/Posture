package fileUtils;

import com.ms3dgenerator.MS3DGenerator;

public class ModelCalThread implements Runnable  {
	private String modelRoute;
	private String actionRoute;
	private String ms3dRoute;
	public ModelCalThread(String modelRoute, String actionRoute, String ms3dRoute){
		this.modelRoute = modelRoute;
		this.actionRoute = actionRoute;
		this.ms3dRoute = ms3dRoute;
	}
	@Override
	public void run() {
	 	try {
	   		MS3DGenerator ms3dg = new MS3DGenerator();
			ms3dg.LoadNGenerate(modelRoute,actionRoute,ms3dRoute);
			System.out.println("Stored at "+ms3dRoute);
		} 
	 	catch (Exception e) {
			e.printStackTrace();
		}
	}
	    
}

